from __future__ import annotations

import logging

from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant

from .const import DOMAIN

PLATFORMS = [
    "device_tracker",
]

_LOGGER = logging.getLogger(__name__)


async def async_setup(
    hass: HomeAssistant,
    config: dict,
) -> bool:
    """Set up Gecoos integration."""

    hass.data.setdefault(
        DOMAIN,
        {},
    )

    return True


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
) -> bool:
    """Set up Gecoos from a config entry."""

    _LOGGER.info(
        "Setting up Gecoos AC Controller Tracker"
    )

    hass.data.setdefault(
        DOMAIN,
        {},
    )

    # ======================================================
    # 直接转交 device_tracker
    #
    # 不在这里提前强制登录。
    # stasearch 可以匿名访问。
    # ======================================================

    await hass.config_entries.async_forward_entry_setups(
        entry,
        PLATFORMS,
    )

    return True


async def async_unload_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
) -> bool:
    """Unload Gecoos."""

    unload_ok = await hass.config_entries.async_unload_platforms(
        entry,
        PLATFORMS,
    )

    if unload_ok:

        hass.data.get(
            DOMAIN,
            {},
        ).pop(
            entry.entry_id,
            None,
        )

    return unload_ok