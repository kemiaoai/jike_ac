from __future__ import annotations

import hashlib
import logging

import aiohttp
import voluptuous as vol

from homeassistant import config_entries
from homeassistant.core import HomeAssistant
from homeassistant.exceptions import HomeAssistantError

from .const import (
    DOMAIN,
    CONF_HOST,
    CONF_PORT,
    CONF_USERNAME,
    CONF_PASSWORD,
    CONF_SCAN_INTERVAL,
    DEFAULT_SCAN_INTERVAL,
    MIN_SCAN_INTERVAL,
    MAX_SCAN_INTERVAL,
)

_LOGGER = logging.getLogger(__name__)


# ==========================================================
# API
# ==========================================================

async def get_json(
    session,
    url,
    method="GET",
    **kwargs,
):
    async with session.request(
        method,
        url,
        timeout=aiohttp.ClientTimeout(total=15),
        **kwargs,
    ) as response:

        response.raise_for_status()

        return await response.json(
            content_type=None
        )


async def gecoos_login(
    session,
    host,
    port,
    username,
    password,
):
    """
    Gecoos 登录。

    实际控制器逻辑：

    GET  /api/getrandom

    MD5(random + password)

    POST /api/sysauth

    ret == 0 -> 失败
    ret != 0 -> 成功
    """

    base_url = f"http://{host}:{port}/api"

    # ------------------------------------------------------
    # 获取随机数
    # ------------------------------------------------------

    random_data = await get_json(
        session,
        f"{base_url}/getrandom",
    )

    random_value = (
        random_data.get("random")
        or random_data.get("rand")
        or random_data.get("value")
    )

    if not random_value:
        raise HomeAssistantError(
            "无法获取 Gecoos random"
        )

    # ------------------------------------------------------
    # MD5
    # ------------------------------------------------------

    password_md5 = hashlib.md5(
        (
            str(random_value)
            + password
        ).encode("utf-8")
    ).hexdigest()

    # ------------------------------------------------------
    # 登录
    # ------------------------------------------------------

    login_data = await get_json(
        session,
        f"{base_url}/sysauth",
        method="POST",
        json={
            "password": password_md5
        },
    )

    ret = login_data.get("ret")

    # Gecoos：
    # ret == 0 = 登录失败
    # ret != 0 = 登录成功
    if ret == 0:
        raise HomeAssistantError(
            "用户名或密码验证失败"
        )

    return login_data.get("token")


async def gecoos_get_devices(
    session,
    host,
    port,
    token=None,
):
    """获取设备列表。"""

    base_url = f"http://{host}:{port}/api"

    params = {
        "numperpage": 30,
        "pagenum": 1,
        "reverse": "",
        "sortkey": "",
        "groupid": "all",
        "searchkey": "",
        "withradio": "",
    }

    headers = {}

    if token:
        headers["sysauth"] = token

    data = await get_json(
        session,
        f"{base_url}/stasearch",
        headers=headers,
        params=params,
    )

    devices = data.get("stalist")

    if not isinstance(devices, list):
        raise HomeAssistantError(
            "Gecoos stasearch 没有返回设备列表"
        )

    return devices


async def validate_connection(
    hass: HomeAssistant,
    host,
    port,
    username,
    password,
):
    """验证控制器。"""

    session = aiohttp.ClientSession()

    try:
        token = None

        # --------------------------------------------------
        # 登录是可选的
        # stasearch 当前支持匿名访问
        # --------------------------------------------------

        try:
            token = await gecoos_login(
                session,
                host,
                port,
                username,
                password,
            )

        except Exception as err:
            _LOGGER.warning(
                "Gecoos 登录失败，但继续尝试 stasearch：%s",
                err,
            )

        # --------------------------------------------------
        # 真正验证设备接口
        # --------------------------------------------------

        devices = await gecoos_get_devices(
            session,
            host,
            port,
            token,
        )

        if not devices:
            raise HomeAssistantError(
                "Gecoos API 返回 0 个设备"
            )

        _LOGGER.info(
            "Gecoos 连接成功，发现 %d 个设备",
            len(devices),
        )

    finally:
        await session.close()


# ==========================================================
# Config Flow
# ==========================================================

class GecoosConfigFlow(
    config_entries.ConfigFlow,
    domain=DOMAIN,
):
    """Gecoos AC Controller 配置流程。"""

    VERSION = 1

    async def async_step_user(
        self,
        user_input=None,
    ):
        errors = {}

        if user_input is not None:

            host = str(
                user_input.get(
                    CONF_HOST,
                    ""
                )
            ).strip()

            port_raw = str(
                user_input.get(
                    CONF_PORT,
                    ""
                )
            ).strip()

            username = str(
                user_input.get(
                    CONF_USERNAME,
                    ""
                )
            ).strip()

            password = str(
                user_input.get(
                    CONF_PASSWORD,
                    ""
                )
            )

            scan_interval_raw = str(
                user_input.get(
                    CONF_SCAN_INTERVAL,
                    DEFAULT_SCAN_INTERVAL,
                )
            ).strip()

            # ------------------------------------------------
            # IP 不能为空
            # ------------------------------------------------

            if not host:
                errors[
                    CONF_HOST
                ] = "required"

            # ------------------------------------------------
            # 端口不能为空
            # ------------------------------------------------

            if not port_raw:
                errors[
                    CONF_PORT
                ] = "required"

            # ------------------------------------------------
            # 端口
            # ------------------------------------------------

            port = None

            if port_raw:

                try:
                    port = int(port_raw)

                    if not (
                        1
                        <= port
                        <= 65535
                    ):
                        errors[
                            CONF_PORT
                        ] = "invalid"

                except ValueError:
                    errors[
                        CONF_PORT
                    ] = "invalid"

            # ------------------------------------------------
            # 扫描间隔
            # ------------------------------------------------

            try:

                scan_interval = int(
                    scan_interval_raw
                )

                if not (
                    MIN_SCAN_INTERVAL
                    <= scan_interval
                    <= MAX_SCAN_INTERVAL
                ):
                    errors[
                        CONF_SCAN_INTERVAL
                    ] = "invalid"

            except ValueError:

                errors[
                    CONF_SCAN_INTERVAL
                ] = "invalid"

                scan_interval = (
                    DEFAULT_SCAN_INTERVAL
                )

            # ------------------------------------------------
            # 验证连接
            # ------------------------------------------------

            if not errors:

                try:

                    await validate_connection(
                        self.hass,
                        host,
                        port,
                        username,
                        password,
                    )

                except Exception as err:

                    _LOGGER.error(
                        "Gecoos 连接验证失败：%s",
                        err,
                    )

                    errors[
                        "base"
                    ] = "cannot_connect"

            # ------------------------------------------------
            # 创建配置
            # ------------------------------------------------

            if not errors:

                await self.async_set_unique_id(
                    f"{host}:{port}"
                )

                self._abort_if_unique_id_configured()

                return self.async_create_entry(
                    title=f"Gecoos {host}:{port}",
                    data={
                        CONF_HOST: host,
                        CONF_PORT: port,
                        CONF_USERNAME: username,
                        CONF_PASSWORD: password,
                        CONF_SCAN_INTERVAL: scan_interval,
                    },
                )

        # ====================================================
        # 表单
        #
        # IP 和端口都故意不给默认值
        # ====================================================

        schema = vol.Schema(
            {
                vol.Required(
                    CONF_HOST,
                    default="",
                ): str,

                vol.Required(
                    CONF_PORT,
                    default="",
                ): str,

                vol.Optional(
                    CONF_USERNAME,
                    default="admin",
                ): str,

                vol.Optional(
                    CONF_PASSWORD,
                    default="",
                ): str,

                vol.Optional(
                    CONF_SCAN_INTERVAL,
                    default=str(
                        DEFAULT_SCAN_INTERVAL
                    ),
                ): str,
            }
        )

        return self.async_show_form(
            step_id="user",
            data_schema=schema,
            errors=errors,
        )