from __future__ import annotations

import logging
from datetime import timedelta
from typing import Any

import aiohttp

from homeassistant.components.device_tracker import (
    ScannerEntity,
    SourceType,
)
from homeassistant.helpers.aiohttp_client import async_get_clientsession
from homeassistant.helpers.device_registry import DeviceInfo
from homeassistant.helpers.update_coordinator import (
    CoordinatorEntity,
    DataUpdateCoordinator,
)

from .const import (
    DOMAIN,
    CONF_HOST,
    CONF_PORT,
    CONF_USERNAME,
    CONF_PASSWORD,
    CONF_SCAN_INTERVAL,
    DEFAULT_SCAN_INTERVAL,
)

_LOGGER = logging.getLogger(__name__)


# ==========================================================
# MAC 地址处理
# ==========================================================

def normalize_mac(value: Any) -> str | None:
    """标准化 MAC 地址。"""

    if value is None:
        return None

    value = str(value).strip().upper()

    if not value:
        return None

    # 去掉 : - . 空格
    raw = (
        value
        .replace(":", "")
        .replace("-", "")
        .replace(".", "")
        .replace(" ", "")
    )

    # MAC 必须是 12 位十六进制
    if len(raw) != 12:
        return None

    try:
        int(raw, 16)
    except ValueError:
        return None

    return ":".join(
        raw[i:i + 2]
        for i in range(0, 12, 2)
    )


# ==========================================================
# Gecoos 设备唯一 ID (强制以 MAC 为绝对核心)
# ==========================================================

def get_device_identifier(
    device: dict[str, Any],
) -> str:
    """获取 Gecoos 客户端唯一标识。"""

    # 1. 严格优先使用 MAC
    mac = normalize_mac(device.get("mac"))
    if mac:
        return f"mac_{mac.replace(':', '')}"

    # 2. 如果绝对没有 MAC，再退回 id
    device_id = device.get("id")
    if device_id is not None:
        value = str(device_id).strip()
        if value:
            return f"id_{value}"

    return "unknown"


# ==========================================================
# 获取设备名称
# ==========================================================

def get_device_name(
    device: dict[str, Any],
) -> str:
    """获取设备显示名称。"""

    hostname = str(
        device.get("hostname") or ""
    ).strip()

    name = str(
        device.get("name") or ""
    ).strip()

    mac = normalize_mac(
        device.get("mac")
    )

    ip = str(
        device.get("ip") or ""
    ).strip()

    if hostname:
        return hostname

    if name:
        return name

    if mac:
        return mac

    if ip:
        return ip

    return "未知设备"


# ==========================================================
# Gecoos API Client
# ==========================================================

class GecoosClient:
    """Gecoos AC Controller API 客户端。"""

    def __init__(
        self,
        hass,
        host: str,
        port: int,
        username: str,
        password: str,
        scan_interval: int = DEFAULT_SCAN_INTERVAL,
    ):
        self.hass = hass
        self.host = host
        self.port = port
        self.username = username
        self.password = password
        self.scan_interval = scan_interval

        self.base_url = (
            f"http://{host}:{port}/api"
        )

        self.token: str | None = None

        self.session = (
            async_get_clientsession(hass)
        )

        self.coordinator = DataUpdateCoordinator(
            hass,
            _LOGGER,
            name="Gecoos AC Controller",
            update_method=self.async_update_data,
            update_interval=timedelta(
                seconds=scan_interval
            ),
        )

    async def _request_json(
        self,
        method: str,
        path: str,
        **kwargs,
    ) -> dict[str, Any]:
        url = f"{self.base_url}{path}"
        headers = kwargs.pop("headers", {})

        if self.token:
            headers["sysauth"] = self.token

        try:
            async with self.session.request(
                method,
                url,
                headers=headers,
                timeout=aiohttp.ClientTimeout(total=15),
                **kwargs,
            ) as response:
                response.raise_for_status()
                data = await response.json(content_type=None)
                if not isinstance(data, dict):
                    raise ValueError("Gecoos API 返回的数据不是 JSON 对象")
                return data
        except Exception as err:
            _LOGGER.error("Gecoos API 请求失败: %s %s - %s", method, url, err)
            raise

    async def async_login(self) -> bool:
        try:
            random_data = await self._request_json("GET", "/getrandom")
            random_value = (
                random_data.get("random")
                or random_data.get("rand")
                or random_data.get("value")
            )

            if not random_value:
                return False

            import hashlib
            password_md5 = hashlib.md5(
                (str(random_value) + self.password).encode("utf-8")
            ).hexdigest()

            login_data = await self._request_json(
                "POST",
                "/sysauth",
                json={"password": password_md5},
            )

            ret = login_data.get("ret")
            if ret == 0:
                self.token = None
                return False

            token = login_data.get("token")
            if token:
                self.token = str(token)

            return True
        except Exception as err:
            self.token = None
            return False

    async def async_get_devices(
        self,
    ) -> list[dict[str, Any]]:
        params = {
            "numperpage": 30,
            "pagenum": 1,
            "reverse": "",
            "sortkey": "",
            "groupid": "all",
            "searchkey": "",
            "withradio": "",
        }

        try:
            data = await self._request_json("GET", "/stasearch", params=params)
            devices = data.get("stalist")
            if isinstance(devices, list):
                return [d for d in devices if isinstance(d, dict)]
        except Exception:
            pass

        old_token = self.token
        self.token = None

        try:
            data = await self._request_json("GET", "/stasearch", params=params)
            devices = data.get("stalist")
            if isinstance(devices, list):
                return [d for d in devices if isinstance(d, dict)]
            return []
        except Exception as err:
            _LOGGER.error("Gecoos 获取设备列表失败：%s", err)
            return []
        finally:
            self.token = old_token

    async def async_update_data(self):
        return await self.async_get_devices()


# ==========================================================
# Device Tracker
# ==========================================================

class GecoosDeviceTracker(
    CoordinatorEntity,
    ScannerEntity,
):
    """Gecoos WiFi 客户端 Device Tracker。"""

    _attr_should_poll = False

    def __init__(
        self,
        coordinator,
        device: dict[str, Any],
        identifier: str,
    ):
        super().__init__(coordinator)

        self.device_data = device
        self._identifier = identifier

        self._attr_unique_id = f"gecoos_{identifier}"
        self._attr_name = get_device_name(device)

        mac = normalize_mac(device.get("mac"))

        connections = set()
        if mac:
            connections.add(("mac", mac))

        # 【关键修复】确保即使设备被其他集成收纳，也能正确注册
        self._attr_device_info = DeviceInfo(
            identifiers={(DOMAIN, identifier)},
            name=self._attr_name,
            manufacturer="Gecoos",
            model=str(device.get("apmodel") or "WiFi Client"),
            connections=connections,
        )

    @property
    def current_data(self) -> dict[str, Any]:
        devices = self.coordinator.data or []
        for device in devices:
            if not isinstance(device, dict):
                continue
            if get_device_identifier(device) == self._identifier:
                return device
        return self.device_data

    @property
    def name(self) -> str:
        return get_device_name(self.current_data)

    @property
    def mac_address(self) -> str | None:
        # 【关键修复】确保始终能够从当前数据中正确提取 MAC
        return normalize_mac(self.current_data.get("mac"))

    @property
    def is_connected(self) -> bool:
        devices = self.coordinator.data or []
        for device in devices:
            if not isinstance(device, dict):
                continue
            if get_device_identifier(device) == self._identifier:
                return True
        return False

    @property
    def state(self):
        return "home" if self.is_connected else "not_home"

    @property
    def source_type(self) -> SourceType:
        return SourceType.ROUTER

    @property
    def extra_state_attributes(self):
        device = self.current_data
        return {
            "id": device.get("id"),
            "mac": normalize_mac(device.get("mac")),
            "ip": device.get("ip") or "",
            "hostname": device.get("hostname") or "",
            "signal": device.get("signal"),
            "radio": device.get("radio") or "",
            "ssid": device.get("ssid") or "",
            "apmac": device.get("apmac") or "",
            "apmodel": device.get("apmodel") or "",
            "rx_rate": device.get("rx_rate"),
            "tx_rate": device.get("tx_rate"),
            "rx_packets": device.get("rx_packets"),
            "tx_packets": device.get("tx_packets"),
            "assoctime": device.get("assoctime"),
            "groupid": device.get("groupid") or "",
        }


# ==========================================================
# Home Assistant Setup
# ==========================================================

async def async_setup_entry(
    hass,
    entry,
    async_add_entities,
):
    data = entry.data

    host = str(data.get(CONF_HOST, "")).strip()
    port = int(data.get(CONF_PORT))
    username = str(data.get(CONF_USERNAME, ""))
    password = str(data.get(CONF_PASSWORD, ""))
    scan_interval = int(data.get(CONF_SCAN_INTERVAL, DEFAULT_SCAN_INTERVAL))

    client = GecoosClient(
        hass=hass,
        host=host,
        port=port,
        username=username,
        password=password,
        scan_interval=scan_interval,
    )

    hass.data.setdefault(DOMAIN, {})
    hass.data[DOMAIN][entry.entry_id] = client

    await client.async_login()
    await client.coordinator.async_config_entry_first_refresh()

    devices = client.coordinator.data or []
    entities = []

    for device in devices:
        if not isinstance(device, dict):
            continue

        identifier = get_device_identifier(device)
        entities.append(
            GecoosDeviceTracker(
                coordinator=client.coordinator,
                device=device,
                identifier=identifier,
            )
        )

    if entities:
        async_add_entities(entities, update_before_add=False)
